
<!DOCTYPE html>
<html>

<head><title>new account</title></head>

<body>
<form action="includes/deposit_click.php" method="POST">
	
	<input type="text" name="account_no" placeholder="account_no">
	<br>
	<input type="text" name="deposit" placeholder="deposit">
	<br>
	<input type="text" name="password" placeholder="password">
	<br>

	<input type="text" name="date" placeholder="date">
	<br>
	<button type="submit" name="submit">click</button>

</form>


</body>
</html>