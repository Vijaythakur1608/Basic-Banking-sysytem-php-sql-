
<!DOCTYPE html>
<html>

<head><title>new user</title></head>

<body>
<form action="includes/new_user_click.php" method="POST">
	<input type="text" name="roll_no" placeholder="roll_no">
	<br>
	<input type="text" name="name" placeholder="name">
	<br>
	<input type="text" name="mobile_no" placeholder="mobile_no">
	<br>
	<button type="submit" name="submit">click</button>

</form>


</body>
</html>