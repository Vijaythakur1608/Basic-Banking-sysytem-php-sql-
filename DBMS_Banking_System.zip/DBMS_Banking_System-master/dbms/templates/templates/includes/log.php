<?php

$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "banking";

$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);