
<!DOCTYPE html>
<html>

<head><title>new account</title></head>

<body>
<form action="includes/loan_click.php" method="POST">
	<input type="text" name="roll_no" placeholder="roll_no">
	<br>
	<input type="text" name="loan_no" placeholder="loan_no">
	<br>
	<input type="text" name="password" placeholder="password">
	<br>
		
	<input type="text" name="account_no" placeholder="account_no">
	<br>

	<input type="text" name="amount_taken" placeholder="amount_taken">
	<br>
	<input type="text" name="amount_remaining" placeholder="amount_remaining">
	<br>
	<input type="text" name="date_of_issue" placeholder="date_of_issue">
	<br>
	<input type="text" name="total_loan_time" placeholder="total_loan_time">
	<br>
	<input type="text" name="amount_paid" placeholder="amount_paid">
	<br>

	<button type="submit" name="submit">click</button>

</form>


</body>
</html>