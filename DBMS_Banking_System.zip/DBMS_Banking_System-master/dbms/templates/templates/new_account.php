
<!DOCTYPE html>
<html>

<head><title>new account</title></head>

<body>
<form action="includes/new_account_click.php" method="POST">
	<input type="text" name="roll_no" placeholder="roll_no">
	<br>
	<input type="text" name="account_no" placeholder="account_no">
	<br>
	<input type="text" name="amount_deposited" placeholder="amount_deposited">
	<br>
	<input type="text" name="password" placeholder="password">
	<br>
	<button type="submit" name="submit">click</button>

</form>


</body>
</html>