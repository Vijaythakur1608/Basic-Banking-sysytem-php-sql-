

<!DOCTYPE html>
<html>
<body>

<h1>User Functions</h1>
<form>
<button type="submit" formaction= "new_user.php">New user</button><br>
<br>

<button type="submit" formaction="new_account.php">create account</button><br>
<br>
<button type="submit" formaction="take_loan.php">take loan</button><br>
<br>
<button type="submit" formaction="deposit.php">withdraw/deposit</button><br>
<br>
<button type="submit" formaction="https://www.w3schools.com/html/">loan transaction</button><br>
<br>
<button type="submit" formaction="https://www.w3schools.com/html/">amount in account</button>


</form>
</body>
</html>
